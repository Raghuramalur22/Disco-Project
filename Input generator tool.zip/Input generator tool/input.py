import pandas as pd
import random

def assign_courses():
    # Ask the user for the Excel file path
    input_excel_file = (input("Enter the path to the Excel file: "))
    

    # Read the Excel file into a pandas DataFrame
    try:
        df = pd.read_excel('/mnt/windows_c/thumbs/1. DISCO PROJECT/input.xlsx')
    except FileNotFoundError:
        print(f"Error: The file '{input_excel_file}' was not found.")
        return
    except pd.errors.EmptyDataError:
        print(f"Error: The file '{input_excel_file}' is empty.")
        return

    # Extract unique courses for the specified course type
    course_type = input("Enter the course type (UGC, HDC, UGE, HDE): ").upper()
    if course_type == 'UGC':
        courses_list = df['UG course'].dropna().unique().tolist()
    elif course_type == 'HDC':
        courses_list = df['HD course'].dropna().unique().tolist()
    elif course_type == 'UGE':
        courses_list = df['UG elective'].dropna().unique().tolist()
    elif course_type == 'HDE':
        courses_list = df['HD elective'].dropna().unique().tolist()
    else:
        print("Invalid course type. Please choose from UGC, HDC, UGE, HDE.")
        return

    while True:
        # Shuffle the courses list to ensure randomness
        random.shuffle(courses_list)

        # Select the specified number of courses randomly
        num_courses_to_assign = int(input("Enter the number of courses to assign: "))
        selected_courses = random.sample(courses_list, min(num_courses_to_assign, len(courses_list)))

        # Print the selected courses
        print(f"Randomly Selected Courses: {';'.join(selected_courses)}")

        # Ask the user if they want another set
        another_set = input("Do you want another set? (yes/no): ").lower()
        if another_set != 'yes':
            break

# Example usage:
assign_courses()

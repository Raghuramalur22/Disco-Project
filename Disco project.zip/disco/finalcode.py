import pandas as pd
from itertools import permutations

def read_faculty_data(excel_file_path):
    df = pd.read_excel(excel_file_path)
    faculty_data = {}

    for index, row in df.iterrows():
        professor = row['Professor']
        faculty_data[professor] = {
            'UG CDC': row['UG CDC'].split(';'),
            'UG EL': row['UG EL'].split(';'),
            'HD CDC': row['HD CDC'].split(';'),
            'HD EL': row['HD EL'].split(';'),
            'Type': row['TYPE']
        }

    return faculty_data

def sort_courses_within_categories(data):
    for professor, preferences in data.items():
        for category in preferences:
            if category != 'Type':
                preferences[category] = sorted(set(preferences[category]), key=preferences[category].index)
    return data

def allocate_courses(data):
    course_points = {}
    for professor, prefs in data.items():
        for category, courses in prefs.items():
            if category != 'Type' and category != 'load left' and category != 'allocated_courses':
                for course in courses:
                    if course not in course_points:
                        course_points[course] = 1

    for professor, prefs in data.items():
        if prefs['Type'] == 'X1':
            prefs['load left'] = 0.5
        elif prefs['Type'] == 'X2':
            prefs['load left'] = 1
        elif prefs['Type'] == 'X3':
            prefs['load left'] = 1.5

        prefs['allocated_courses'] = []

    def allocate_course(professor, course, category):
        if professor['load left'] > 0 and course in professor[category] and course_points[course] > 0:
            if professor['load left'] >= 0.5 and course_points[course] >= 0.5:
                professor['allocated_courses'].append(course)
                professor['load left'] -= 0.5
                course_points[course] -= 0.5

                if professor['load left'] > 0 and course in professor[category] and course_points[course] > 0:
                    professor['allocated_courses'].append(course)
                    professor['load left'] -= 0.5
                    course_points[course] -= 0.5
                else:
                    for prof, pref in data.items():
                        if pref['load left'] > 0 and course in pref[category] and course_points[course] > 0 and prof != professor:
                            pref['allocated_courses'].append(course)
                            pref['load left'] -= 0.5
                            course_points[course] -= 0.5
                            break

    for professor, prefs in data.items():
        for category, courses in prefs.items():
            if category != 'Type' and category != 'load left' and category != 'allocated_courses':
                for course in courses:
                    allocate_course(prefs, course, category)

    for professor, prefs in data.items():
        for course in prefs['allocated_courses']:
            if course_points[course] == 0.5:
                if prefs['load left'] == 0:
                    prefs['allocated_courses'].remove(course)
                    prefs['load left'] += 0.5
                    course_points[course] += 0.5

    print("Professor : Allocated Courses, Remaining Load")
    for professor, prefs in data.items():
        allocated_courses = ', '.join(prefs['allocated_courses'])
        print(f"{professor} : {allocated_courses}, {prefs['load left']}")

def find_unique_allocations(faculty_data):
    professors = list(faculty_data.keys())
    all_permutations = permutations(professors)

    unique_allocations = []

    for permutation in all_permutations:
        current_data = {prof: faculty_data[prof] for prof in permutation}
        allocate_courses(current_data)
       
        load_left_sum = sum(current_data[prof]['load left'] for prof in current_data)
        if load_left_sum <= 0.5 and any(current_data[prof]['load left'] > 0 for prof in current_data):
            allocation = tuple(sorted((prof, tuple(sorted(current_data[prof]['allocated_courses']))) for prof in current_data))
            unique_allocations.append(allocation)

    unique_allocations = [list(x) for x in set(tuple(sorted(a)) for a in unique_allocations)]

    print("\nPossible Allocations:")
    for idx, allocation in enumerate(unique_allocations, start=1):
        print(f"Possible Allocation {idx}:")
        for prof, courses in allocation:
            print(f"{prof} : {', '.join(courses)}")
        print()

# Example usage
excel_file_path = r'C:\Users\Harshith\Desktop\input\PL-1.xlsx'
faculty_data = read_faculty_data(excel_file_path)
sorted_faculty_data = sort_courses_within_categories(faculty_data)
find_unique_allocations(sorted_faculty_data)